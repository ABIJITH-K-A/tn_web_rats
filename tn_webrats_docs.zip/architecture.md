# System Architecture

Client Browser
↓
Frontend (HTML / Bootstrap / JS)
↓
Firebase Auth
↓
Firestore Database
↓
Backend APIs / Cloud Functions
↓
External Services

External:
Razorpay (payments)
S3 / MinIO (files)
EmailJS (emails)