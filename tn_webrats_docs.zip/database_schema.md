# Firestore Schema

users
orders
wallets
transactions
allocations
withdrawals
messages
reports
notifications
inviteKeys

Transactions types:
order_earning
salary_allotment
bonus
withdrawal
refund