# TN WEB RATS Context

Platform type: Student freelancing marketplace.

Roles:
Owner → Superadmin → Admin → Manager → Worker → Client

Worker rules:
- Only one active order
- Orders filtered by specialization

Earnings:
Worker: 75%
Platform: 25%

Wallet fields:
balance
availableBalance
pendingWithdrawals
totalEarned
totalWithdrawn