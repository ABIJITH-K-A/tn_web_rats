# TN WEB RATS

Student‑run digital services platform where clients place orders and workers complete tasks.

Core flow:
Client → Booking → Payment → Order Queue → Worker/Manager Assignment → Progress → Delivery → Review → Wallet Credit