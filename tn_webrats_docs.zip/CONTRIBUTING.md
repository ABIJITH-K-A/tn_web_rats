# Contributing

Read docs before coding.

Branch naming:
feature/*
bugfix/*
refactor/*

Never implement financial logic in frontend.
Update documentation when features change.