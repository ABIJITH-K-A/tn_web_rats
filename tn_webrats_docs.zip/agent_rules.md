# AI Agent Rules

Understand architecture before coding.
Modify only necessary files.
Do not remove existing logic unless instructed.

Security rules:
Financial logic must run server‑side.
Never update wallet balances directly.