# Development Rules

Use modular architecture.
Avoid large files.
Use descriptive variables.

Backend must handle:
wallet updates
withdrawals
salary allocation
payment verification